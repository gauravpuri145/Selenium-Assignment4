package Assignment1;

public class Marks {
    public static void main(String[] args) {
        int eng = 78;
        int hindi = 12;
        int math = 89;
        int punjabi = 55;
        int science = 35;

        if(eng > hindi && eng > math && eng > punjabi && eng > science){
            System.out.println(eng);
        }
        else if(hindi > eng && hindi > math && hindi > punjabi && hindi > science){
            System.out.println(hindi);
        }
        else if(math > hindi && math > eng && math > punjabi && math > science){
            System.out.println(math);
        }
        else if(punjabi > hindi && punjabi > math && punjabi > eng && punjabi > science){
            System.out.println(punjabi);
        }
        else{
            System.out.println(science);
        }
    }
}
