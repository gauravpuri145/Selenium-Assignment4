package Assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Listcontains {

    private static boolean hasMatchingSubstring(String str, List<String> substrings) {
        for (String substring : substrings) {
            if (str.contains(substring)) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        String word = "Mobile";
        List<String> l1 = new ArrayList<>(Arrays.asList("Web Automation", "API Automation", "Mobile Automation"));

        System.out.println(hasMatchingSubstring(word, l1) ? "False" : "True");
    }
}
