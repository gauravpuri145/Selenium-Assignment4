package Assignment3;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class Listforloop {
    public static void main(String[] args) {
        List<Integer> l1 = new ArrayList<>();
        l1 = Arrays.asList(10,20,30,40,50);

        for(int i = 0; i < l1.size(); i++){
            System.out.println(l1.get(i));
        }
    }
}
