package Assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Listiterator {

    public static void main(String[] args) {
        List<Integer> l3 = new ArrayList<>();
        l3 = Arrays.asList(10, 20, 30, 40, 50);

        Iterator<Integer> lstitr = l3.iterator();
        while(lstitr.hasNext()){
            int lstelement = lstitr.next();
            System.out.println(lstelement);
        }

    }
}
