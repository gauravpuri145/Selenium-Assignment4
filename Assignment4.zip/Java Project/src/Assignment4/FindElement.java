package Assignment4;

import java.util.*;

public class FindElement {

    public static void main(String[] args) {
        List<Integer> l1 = new ArrayList<>(Arrays.asList(10,45, 90,45, 23, 90, 44));
        System.out.println("Second Element is " + l1.get(1));
        System.out.println("Second Last Element is " + l1.get(l1.size()-2));
    }
}
