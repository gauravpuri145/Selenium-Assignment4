package Assignment4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NestedList {
    public static void main(String[] args) {
        List<Integer> l1 = new ArrayList<>(Arrays.asList(11,22,33));
        List<Integer> l2 = new ArrayList<>(Arrays.asList(9,19,29));
        List<Integer> l3 = new ArrayList<>(Arrays.asList(7,17,27));

        List<List<Integer>> result = new ArrayList<>();
        result.add(l1);
        result.add(l2);
        result.add(l3);

        System.out.println("Nested List is " + result);

    }
}
