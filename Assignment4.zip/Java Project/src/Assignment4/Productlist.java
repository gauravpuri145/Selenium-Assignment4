package Assignment4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Productlist {

    public static void main(String[] args) {
        String word = "Git";
        List<String> l1 = new ArrayList<>(Arrays.asList("Git", "Github", "GitLab", "GitBash", "Selenium", "Java", "Maven"));

        for(int i = 0; i < l1.size(); i++){
            if(l1.get(i).contains(word)){
                System.out.println(l1.get(i));
            }
        }


    }
}
