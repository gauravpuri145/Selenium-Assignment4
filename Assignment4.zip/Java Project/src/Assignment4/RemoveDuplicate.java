package Assignment4;



import java.util.*;

public class RemoveDuplicate {
    public static void main(String[] args) {
        List<String> l1 = new ArrayList<>(Arrays.asList("Java", "TestNG", "Maven", "Java"));
        System.out.println("Input List is " + l1);

        Set<String> s1 = new LinkedHashSet<>(l1);
        System.out.println("Output is "+ s1);
    }
}
