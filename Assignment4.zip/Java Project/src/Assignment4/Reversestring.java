package Assignment4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Reversestring {
    public static void main(String[] args) {
        List<String> l1 = new ArrayList<>(Arrays.asList("Java", "Selenium", "TestNG", "Git", "Github"));
        for(int i = l1.size()-1; i >= 0; i--){
            System.out.println(l1.get(i));
        }
    }
}
